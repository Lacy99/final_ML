# Thai Word Finder — ระบบค้นหาคำที่มีความหมายใกล้เคียงด้วย AI for Thai

[![React](https://img.shields.io/badge/Frontend-React%20%2B%20Vite-blue)](https://vitejs.dev/)
[![PHP](https://img.shields.io/badge/Backend-PHP%208%2B%20(cURL)-8892BF)](https://www.php.net/)
[![AI for Thai](https://img.shields.io/badge/AI%20API-AI%20for%20Thai-00bcd4)](https://aiforthai.in.th/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

โครงงานพัฒนาเว็บแอปพลิเคชันสำหรับวิเคราะห์และค้นหาคำภาษาไทยที่มีความหมายใกล้เคียงและบริบทสัมพันธ์กัน โดยเชื่อมต่อกับ **AI for Thai Word Similarity API** (สวทช./NECTEC) จริง ผ่านสถาปัตยกรรม Full-Stack ที่ปลอดภัย ออกแบบเพื่อการส่งงานมหาวิทยาลัยในรายวิชาทางด้าน Machine Learning / Web Application Development

---

## 🌟 ฟังก์ชันหลักของระบบ (Features)

1. **หน้าแรก (Home):**
   - แนะนำระบบ คำอธิบาย และตัวอย่างคำค้นหายอดนิยม
   - สรุปความสามารถหลักของโมเดล AI ภาษาไทย
2. **ระบบค้นหาคำภาษาไทย (Word Similarity Search):**
   - ค้นหาคำภาษาไทยด้วยโมเดล Word2Vec แบบเรียลไทม์
   - รองรับการปรับจำนวนคำผลลัพธ์: **5, 10, 15 และ 20 คำ**
   - เลือกระหว่าง 2 โมเดลภาษา:
     - `thwiki`: โมเดลภาษาทางการ/สารานุกรมจาก Thai Wikipedia
     - `twitter`: โมเดลภาษาบทสนทนา/โซเชียลมีเดียจาก Thai Twitter
3. **การแสดงผลลัพธ์ (Result Visualization):**
   - แสดงลำดับคำ (Rank 1, 2, 3...)
   - คะแนนความคล้ายทางเวกเตอร์ (Cosine Similarity Score)
   - คำนวณคะแนนเป็นเปอร์เซ็นต์ (`Score × 100`)
   - แถบความคืบหน้า (Progress Bar) ปรับตามค่าคะแนน
   - ปุ่มคลิกเพื่อคัดลอกคำ (Copy to Clipboard)
4. **ประวัติการค้นหา (Search History):**
   - บันทึกคำค้นหา โมเดล และเวลาลงใน `localStorage` ของเบราว์เซอร์
   - คลิกเพื่อค้นหาคำเดิมซ้ำได้ทันที (Re-search)
   - ปุ่มลบรายการและปุ่มล้างประวัติทั้งหมด
   - ปลอดภัย ไม่มีการจัดเก็บ API Key ใดๆ ในฝั่ง Client
5. **หน้าเกี่ยวกับระบบ (About & Architecture):**
   - อธิบายสถาปัตยกรรม Client-Server และ Data Flow 4 ขั้นตอน
   - รายละเอียดเชิงทฤษฎีของโมเดล Word2Vec และ Cosine Similarity

---

## 🛠️ เทคโนโลยีที่ใช้ (Tech Stack)

| ส่วนของระบบ | เทคโนโลยี | รายละเอียด |
| :--- | :--- | :--- |
| **Frontend** | React 18 + Vite | สถาปัตยกรรม Component สมัยใหม่ เรนเดอร์รวดเร็ว |
| **Styling** | Pure Handcrafted CSS | เขียน CSS เอง 100% (ธีม Modern AI Dashboard โทนสีกรมท่า-น้ำเงิน-ขาว) โดยไม่พึ่งพา Tailwind หรือ Bootstrap |
| **Backend** | PHP 8.2+ บน XAMPP | RESTful Proxy API รองรับ HTTP GET/POST ตรวจสอบข้อมูลนำเข้า |
| **API Client** | PHP cURL | เรียก AI for Thai พร้อม Header Authentication และ Timeout |
| **AI Service** | AI for Thai (NECTEC) | บริการ Word Similarity API (`https://api.aiforthai.in.th/thaiwordsim`) |
| **Dev Tool** | Antigravity CLI (`agy`) | เครื่องมือช่วยพัฒนา Full-Stack AI Application |

---

## 🔒 ความปลอดภัยของ API Key (Security Architecture)

- **ไม่เปิดเผย API Key สู่เบราว์เซอร์:** Frontend เรียกเฉพาะ Backend PHP เท่านั้น
- **การจัดเก็บข้อมูลลับ:** จัดเก็บ `AIFORTHAI_API_KEY` ในไฟล์ `backend/.env`
- **การป้องกันบน Git:** ไฟล์ `backend/.env` ถูกระบุไว้ใน `.gitignore` เรียบร้อยแล้ว จึงไม่ถูก Commit ขึ้น GitHub เด็ดขาด
- **มีไฟล์เทมเพลต:** จัดเตรียม `backend/.env.example` ให้พร้อมนำไปตั้งค่า

---

## 📁 โครงสร้างโปรเจกต์ (Project Structure)

```text
final_ML/
├── backend/
│   ├── api/
│   │   ├── word-similarity.php   # Endpoint หลักสำหรับค้นหาคำ (PHP cURL Proxy)
│   │   └── health.php            # Endpoint ตรวจสอบสถานะการทำงานของเซิร์ฟเวอร์
│   ├── config.php                # ตัวอ่าน .env, จัดการ CORS และ Helper Functions
│   ├── .env                      # ไฟล์เก็บ API Key จริง (ห้าม Commit ขึ้น Git)
│   └── .env.example              # ตัวอย่างไฟล์ Environment
├── frontend/
│   ├── public/
│   │   └── favicon.svg           # ไอคอน AI Brain Node
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx        # แถบเมนูด้านบน พร้อมสถานะ Backend
│   │   │   ├── Footer.jsx        # ส่วนท้ายของหน้าเว็บ
│   │   │   ├── HomeTab.jsx       # หน้าแรกและแนะนำตัวอย่างคำ
│   │   │   ├── SearchTab.jsx     # หน้าค้นหาคำ ตัวเลือก และการ์ดผลลัพธ์
│   │   │   ├── ResultCard.jsx    # คอมโพเนนต์การ์ดคำศัพท์แต่ละคำ
│   │   │   ├── HistoryTab.jsx    # คอมโพเนนต์ประวัติการค้นหา
│   │   │   ├── AboutTab.jsx      # หน้าอธิบายสถาปัตยกรรมและ AI for Thai
│   │   │   └── ApiKeyAlert.jsx   # กล่องแนะนำขั้นตอนการตั้งค่า API Key
│   │   ├── App.jsx               # คอมโพเนนต์หลักและระบบจัดการ State
│   │   ├── App.css               # สไตล์ลิ่งคอมโพเนนต์ Pure CSS
│   │   ├── index.css             # ตัวแปรสี ฟอนต์ Prompt และการรีเซ็ตพื้นฐาน
│   │   └── main.jsx              # จุดเริ่มต้นการเรนเดอร์ React
│   ├── index.html                # ไฟล์ HTML หลัก นำเข้า Google Fonts
│   ├── package.json              # รายการ Dependencies
│   └── vite.config.js            # การตั้งค่า Vite และ Reverse Proxy ไปยัง Backend
├── docs/
│   └── VIDEO_SCRIPT.md           # บทพูดภาษาไทยสำหรับบันทึกวิดีโอ 5–8 นาที
├── .gitignore                    # ป้องกันไฟล์ Node Modules และ .env
└── README.md                     # เอกสารแนะนำโปรเจกต์นี้
```

---

## 🚀 ขั้นตอนการติดตั้งและรันระบบบน Windows

### 1. ความต้องการของระบบ (Prerequisites)
- **Node.js:** เวอร์ชั่น 18 ขึ้นไป (ตรวจสอบด้วย `node -v`)
- **PHP:** เวอร์ชั่น 8.0 ขึ้นไป (ติดตั้งผ่าน XAMPP หรือ Standalone ตรวจสอบด้วย `php -v`)

---

### 2. การตั้งค่า Backend และ API Key

1. เข้าไปที่โฟลเดอร์โปรเจกต์:
   ```powershell
   cd C:\xampp\htdocs\final_ML
   ```

2. สร้างไฟล์ `backend/.env` จากไฟล์ตัวอย่าง:
   ```powershell
   Copy-Item backend\.env.example backend\.env
   ```

3. เปิดไฟล์ `backend/.env` ด้วย Text Editor และใส่ API Key ที่ได้รับจาก AI for Thai:
   ```env
   AIFORTHAI_API_KEY=รหัสคีย์ของคุณที่นี่
   ```
   *(สมัครและสร้าง API Key ฟรีได้ที่ https://aiforthai.in.th/)*

4. รัน PHP Server (เลือกวิธีใดวิธีหนึ่ง):
   - **วิธีที่ 1 (สะดวกที่สุด ผ่าน PHP CLI):**
     ```powershell
     php -S localhost:8000
     ```
   - **วิธีที่ 2 (ผ่าน Apache ใน XAMPP):**
     เปิด **XAMPP Control Panel** แล้วกดปุ่ม **Start** ที่โมดูล **Apache**

---

### 3. การติดตั้งและรัน Frontend

เปิดหน้าต่าง PowerShell ใหม่:
```powershell
cd C:\xampp\htdocs\final_ML\frontend
npm install
npm run dev
```

เมื่อรันสำเร็จ ให้เปิดเว็บเบราว์เซอร์ไปที่:
👉 **http://localhost:5173/**

---

## 🧪 การทดสอบระบบ (Testing Guide)

| รายการทดสอบ | ขั้นตอน | ผลลัพธ์ที่คาดหวัง |
| :--- | :--- | :--- |
| **1. ทดสอบ Backend Health** | เข้า `http://localhost:8000/backend/api/health.php` | ได้ JSON แสดง `status: "ok"` และสถานะการเชื่อมต่อ |
| **2. ทดสอบค้นหาคำปกติ** | ป้อนคำว่า "สวย", เลือก 5 คำ, โมเดล `thwiki` แล้วกดค้นหา | ได้การ์ดผลลัพธ์ 5 คำ เช่น น่ารัก, มีเสน่ห์, สาวสวย... |
| **3. ทดสอบสลับโมเดล** | สลับเป็นโมเดล `twitter` | ได้ผลลัพธ์จากบทสนทนา เช่น มีเสน่ห์, น่ารัก, หล่อ |
| **4. ทดสอบคำว่างเปล่า** | ลบคำในช่องค้นหา แล้วกด Enter | ระบบปฏิเสธพร้อมแจ้งเตือน "กรุณาระบุคำภาษาไทย" (HTTP 400) |
| **5. ทดสอบกรณีไม่ใส่ API Key** | ตั้งค่า `AIFORTHAI_API_KEY=your_api_key_here` ใน `.env` | หน้าเว็บแสดงกล่องแจ้งเตือนสีส้ม แนะนำขั้นตอนการขอคีย์อย่างชัดเจน |
| **6. ทดสอบคัดลอกคำ** | คลิกปุ่ม "คัดลอก" บนการ์ดผลลัพธ์ | ปุ่มเปลี่ยนเป็น "คัดลอกแล้ว" และคำถูกคัดลอกลง Clipboard |
| **7. ทดสอบประวัติการค้นหา** | ไปที่แท็บ "ประวัติ" | ปรากฏรายการคำที่เคยค้นหา สามารถกด "ค้นหาซ้ำ" หรือ "ล้างประวัติ" ได้ |

---

## 📤 ขั้นตอนการนำ Source Code ขึ้น GitHub

1. ตรวจสอบสถานะและไฟล์ที่ไม่ต้องการ:
   ```powershell
   git status
   ```
   *(ตรวจสอบให้แน่ใจว่าไม่มีไฟล์ `backend/.env` อยู่ในรายการ)*

2. เริ่มต้น Git และ Commit:
   ```powershell
   git init
   git add .
   git commit -m "feat: initial commit of Thai Word Finder project"
   ```

3. เปลี่ยนชื่อ Branch หลักเป็น `main`:
   ```powershell
   git branch -M main
   ```

4. เชื่อมโยงกับ GitHub Repository ของคุณ:
   ```powershell
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   ```

5. Push โค้ดขึ้นสู่ GitHub:
   ```powershell
   git push -u origin main
   ```

---

## ⚠️ ข้อจำกัดและหมายเหตุของระบบ (Limitations & Notes)

1. **ขอบเขตคำศัพท์ (Vocabulary Limit):**
   โมเดล Word2Vec จะค้นหาได้เฉพาะคำที่มีอยู่ในคลังข้อมูลที่เทรนไว้ (Vocabulary) หากค้นหาคำทับศัพท์ใหม่หรือคำที่สะกดผิด โมเดลจะส่งค่าว่างกลับมา
2. **ความหมายของ Similarity Score:**
   คะแนนความคล้าย (Cosine Similarity) วัดจากทิศทางเวกเตอร์ในบริบทแวดล้อมทางภาษา ไม่ได้หมายความว่าคำทั้งสองมีความหมายเหมือนกันทุกประการเสมอไป เช่น "ดำ" กับ "ขาว" อาจมีคะแนนสูงเนื่องจากมักปรากฏในบริบทการเปรียบเทียบคล้ายกัน
3. **โควต้าการเรียกใช้บริการ:**
   AI for Thai มีการจำกัดโควต้าการเรียกใช้งานตามสิทธิ์ของบัญชีผู้ใช้แต่ละประเภท

---

## 👨‍💻 พัฒนาโดย
- โครงงานส่งงานมหาวิทยาลัย วิชา Machine Learning / Advanced Web Programming
- พัฒนาด้วยความช่วยเหลือของ **Antigravity CLI (`agy`)**
