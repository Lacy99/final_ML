<?php
/**
 * Thai Word Finder - Backend Health Check Endpoint
 * URL: GET /backend/api/health.php
 */

require_once __DIR__ . '/../config.php';

$apiKey = getAiForThaiApiKey();
$isKeyConfigured = !empty($apiKey) && $apiKey !== 'your_api_key_here';

$healthData = [
    'status' => 'ok',
    'service' => 'Thai Word Finder Backend API',
    'version' => '1.0.0',
    'php_version' => PHP_VERSION,
    'curl_extension' => extension_loaded('curl'),
    'api_key_configured' => $isKeyConfigured,
    'supported_models' => ['thwiki', 'twitter'],
    'timestamp' => date('c')
];

sendJsonResponse($healthData, 200);
