<?php
/**
 * Thai Word Finder - Word Similarity API Proxy
 * เชื่อมต่อกับ AI for Thai Word Similarity API อย่างปลอดภัย
 * Endpoint: https://api.aiforthai.in.th/thaiwordsim
 */

require_once __DIR__ . '/../config.php';

// 1. รับข้อมูลจาก Frontend (รองรับทั้ง JSON Body และ FormData / POST / GET)
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$params = [];

if ($method === 'POST') {
    $rawInput = file_get_contents('php://input');
    $jsonData = json_decode($rawInput, true);

    if (json_last_error() === JSON_ERROR_NONE && is_array($jsonData)) {
        $params = $jsonData;
    } else {
        $params = $_POST;
    }
} elseif ($method === 'GET') {
    $params = $_GET;
} else {
    sendJsonResponse([
        'success' => false,
        'error' => 'METHOD_NOT_ALLOWED',
        'message' => 'อนุญาตเฉพาะ HTTP GET และ POST เท่านั้น'
    ], 405);
}

// 2. ดึงและตรวจสอบข้อมูลนำเข้า
$word = isset($params['word']) ? trim((string)$params['word']) : '';
$numword = isset($params['numword']) ? (int)$params['numword'] : 10;
$model = isset($params['model']) ? trim((string)$params['model']) : 'thwiki';

// 2.1 ตรวจสอบคำค้นหา (ห้ามว่าง)
if ($word === '') {
    sendJsonResponse([
        'success' => false,
        'error' => 'EMPTY_WORD',
        'message' => 'กรุณาระบุคำภาษาไทยที่ต้องการค้นหา'
    ], 400);
}

// 2.2 ตรวจสอบจำนวนคำ (ต้องอยู่ในช่วง 1 ถึง 20)
if ($numword < 1 || $numword > 20) {
    sendJsonResponse([
        'success' => false,
        'error' => 'INVALID_NUMWORD',
        'message' => 'จำนวนคำที่ต้องการค้นหา (numword) ต้องอยู่ระหว่าง 1 ถึง 20'
    ], 400);
}

// 2.3 ตรวจสอบโมเดล (ต้องเป็น thwiki หรือ twitter)
$allowedModels = ['thwiki', 'twitter'];
if (!in_array($model, $allowedModels, true)) {
    sendJsonResponse([
        'success' => false,
        'error' => 'INVALID_MODEL',
        'message' => "โมเดลไม่ถูกต้อง รองรับเฉพาะ 'thwiki' (Thai Wikipedia) และ 'twitter' (Thai Twitter) เท่านั้น"
    ], 400);
}

// 3. ตรวจสอบการตั้งค่า API Key
$apiKey = getAiForThaiApiKey();
if (empty($apiKey) || $apiKey === 'your_api_key_here') {
    sendJsonResponse([
        'success' => false,
        'error' => 'MISSING_API_KEY',
        'message' => 'ยังไม่ได้ตั้งค่า AIFORTHAI_API_KEY ในไฟล์ backend/.env กรุณาสมัครและนำ API Key จาก https://aiforthai.in.th มาใส่ใน backend/.env ก่อนใช้งาน',
        'guide' => [
            'step_1' => 'สมัครสมาชิกที่ https://aiforthai.in.th/',
            'step_2' => 'ไปที่หน้าแดชบอร์ด แล้วคัดลอก Apikey',
            'step_3' => 'เปิดไฟล์ backend/.env แล้วใส่ AIFORTHAI_API_KEY=<API_KEY_ของคุณ>'
        ]
    ], 400);
}

// 4. เชื่อมต่อ AI for Thai Word Similarity API ผ่าน PHP cURL
$apiUrl = 'https://api.aiforthai.in.th/thaiwordsim';
$postFields = http_build_query([
    'word' => $word,
    'numword' => $numword,
    'model' => $model
]);

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postFields,
    CURLOPT_HTTPHEADER => [
        'Apikey: ' . $apiKey,
        'Content-Type: application/x-www-form-urlencoded'
    ],
    CURLOPT_TIMEOUT => 15,          // Timeout 15 วินาที
    CURLOPT_CONNECTTIMEOUT => 10,   // Connect Timeout 10 วินาที
    CURLOPT_SSL_VERIFYPEER => true
]);

$responseBody = curl_exec($ch);
$curlErrno = curl_errno($ch);
$curlError = curl_error($ch);
$httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// 5. จัดการกรณี cURL ล้มเหลว หรือ Timeout
if ($curlErrno !== 0) {
    sendJsonResponse([
        'success' => false,
        'error' => 'NETWORK_ERROR',
        'message' => 'ไม่สามารถเชื่อมต่อไปยัง AI for Thai API ได้: กรุณาตรวจสอบการเชื่อมต่ออินเทอร์เน็ตหรือสถานะเซิร์ฟเวอร์'
    ], 502);
}

// 6. ตรวจสอบ HTTP Status Code จากเซิร์ฟเวอร์ปลายทาง
if ($httpStatusCode !== 200) {
    // พยายามแกะ error response ถ้ามี
    $upstreamErr = json_decode($responseBody, true);
    $errorMessage = 'เซิร์ฟเวอร์ AI for Thai ตอบกลับด้วยรหัสข้อผิดพลาด ' . $httpStatusCode;
    
    if (is_array($upstreamErr) && isset($upstreamErr['message'])) {
        $errorMessage .= ' (' . $upstreamErr['message'] . ')';
    }

    sendJsonResponse([
        'success' => false,
        'error' => 'API_UPSTREAM_ERROR',
        'http_status' => $httpStatusCode,
        'message' => $errorMessage
    ], 502);
}

// 7. แปลงผลลัพธ์ JSON จาก AI for Thai
$data = json_decode($responseBody, true);
if (json_last_error() !== JSON_ERROR_NONE || !isset($data['words']) || !is_array($data['words'])) {
    sendJsonResponse([
        'success' => false,
        'error' => 'INVALID_API_RESPONSE',
        'message' => 'รูปแบบผลลัพธ์ที่ได้รับจาก AI for Thai ไม่ถูกต้อง'
    ], 502);
}

// 8. จัดรูปแบบผลลัพธ์ให้พร้อมแสดงผลบน Frontend
$formattedWords = [];
foreach ($data['words'] as $index => $item) {
    $itemWord = isset($item['word']) ? (string)$item['word'] : '';
    $rawScore = isset($item['score']) ? (float)$item['score'] : 0.0;
    
    // คำนวณเป็นเปอร์เซ็นต์ (score x 100)
    $percentage = round($rawScore * 100, 2);

    $formattedWords[] = [
        'rank' => $index + 1,
        'word' => $itemWord,
        'score' => $rawScore,
        'percentage' => $percentage
    ];
}

$modelLabels = [
    'thwiki' => 'Thai Wikipedia (ภาษาทางการ/สารานุกรม)',
    'twitter' => 'Thai Twitter (ภาษาโซเชียลมีเดีย/บทสนทนา)'
];

sendJsonResponse([
    'success' => true,
    'query' => [
        'word' => $word,
        'numword' => $numword,
        'model' => $model,
        'model_label' => $modelLabels[$model] ?? $model
    ],
    'count' => count($formattedWords),
    'words' => $formattedWords,
    'source' => 'AI for Thai Word Similarity API',
    'timestamp' => date('c')
], 200);
