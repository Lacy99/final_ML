<?php
/**
 * Thai Word Finder - Backend Configuration & Helpers
 * ทำหน้าที่โหลดไฟล์ .env, จัดการ CORS และตั้งค่าความปลอดภัย
 */

// ป้องกัน Direct Access ถ้าจำเป็น และเปิดการตั้งค่า Headers พื้นฐาน
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// รองรับ Preflight OPTIONS Request ของ Browser
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

/**
 * ฟังก์ชันอ่านไฟล์ .env อย่างปลอดภัย
 * @param string $filePath ตำแหน่งไฟล์ .env
 * @return array ข้อมูล key-value จากไฟล์ .env
 */
function loadEnv($filePath = __DIR__ . '/.env'): array {
    $env = [];
    if (!file_exists($filePath)) {
        return $env;
    }

    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        // ข้าม Comment (#)
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        if (str_contains($line, '=')) {
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);

            // ตัดเครื่องหมายคำพูดรอบข้อความถ้ามี
            if (
                (str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                (str_starts_with($value, "'") && str_ends_with($value, "'"))
            ) {
                $value = substr($value, 1, -1);
            }

            $env[$key] = $value;
        }
    }
    return $env;
}

/**
 * ดึงค่า API Key จาก .env หรือ Server Environment
 * @return string|null
 */
function getAiForThaiApiKey(): ?string {
    // 1. ตรวจสอบจาก System Environment
    $key = getenv('AIFORTHAI_API_KEY');
    if ($key && trim($key) !== '') {
        return trim($key);
    }

    // 2. ตรวจสอบจากไฟล์ .env
    $env = loadEnv();
    if (!empty($env['AIFORTHAI_API_KEY'])) {
        return trim($env['AIFORTHAI_API_KEY']);
    }

    return null;
}

/**
 * ส่ง JSON Response พร้อม HTTP Status Code
 */
function sendJsonResponse(array $data, int $statusCode = 200): void {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit();
}
