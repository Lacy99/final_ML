import React from 'react';
import { History, Trash2, ArrowUpRight, Search, Clock, ShieldCheck } from 'lucide-react';

export default function HistoryTab({ history, onSelectHistoryItem, onClearHistory, onDeleteHistoryItem }) {
  return (
    <div className="history-page-container">
      <div className="history-header">
        <div>
          <h2 className="history-title">
            <History size={24} color="#2563eb" />
            <span>ประวัติการค้นหาคำ</span>
          </h2>
          <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.25rem' }}>
            รายการคำที่คุณเคยค้นหาในเบราว์เซอร์นี้ สามารถคลิกเพื่อค้นหาใหม่อีกครั้งได้ทันที
          </p>
        </div>

        {history.length > 0 && (
          <button className="btn-small btn-danger" onClick={onClearHistory} title="ล้างประวัติการค้นหาทั้งหมด">
            <Trash2 size={16} />
            <span>ล้างประวัติทั้งหมด</span>
          </button>
        )}
      </div>

      {/* Storage Information Notice */}
      <div className="alert-card alert-warning" style={{ marginBottom: '1.5rem' }}>
        <ShieldCheck size={20} color="#f59e0b" style={{ flexShrink: 0 }} />
        <div style={{ fontSize: '0.88rem' }}>
          <strong>นโยบายการจัดเก็บข้อมูล:</strong> ประวัติการค้นหาถูกบันทึกไว้ใน{' '}
          <code>localStorage</code> บนเครื่องคอมพิวเตอร์ของคุณเท่านั้น ไม่มีการบันทึกบนเซิร์ฟเวอร์ภายนอก
          และไม่มีการเก็บ API Key ใดๆ ข้อมูลจะคงอยู่จนกว่าคุณจะกดล้างประวัติหรือล้างแคชของเบราว์เซอร์
        </div>
      </div>

      {history.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">
            <Clock size={32} />
          </div>
          <h3 className="empty-title">ยังไม่มีประวัติการค้นหา</h3>
          <p className="empty-desc">
            เมื่อคุณทำการค้นหาคำผ่านระบบ รายการคำและโมเดลที่ใช้จะถูกบันทึกไว้ที่นี่เพื่อให้คุณกลับมาดูหรือค้นหาซ้ำได้สะดวก
          </p>
        </div>
      ) : (
        <div className="history-list">
          {history.map((item, index) => (
            <div key={`${item.word}-${item.timestamp}-${index}`} className="history-item">
              <div className="history-item-left">
                <span className="history-word-tag">{item.word}</span>
                <div className="history-meta-tags">
                  <span className="meta-pill">
                    {item.model === 'thwiki' ? 'Wikipedia' : 'Twitter'}
                  </span>
                  <span className="meta-pill">{item.numword} คำ</span>
                  {item.resultCount !== undefined && (
                    <span className="meta-pill">พบ {item.resultCount} ผลลัพธ์</span>
                  )}
                  <span className="history-date">
                    {new Date(item.timestamp).toLocaleString('th-TH', {
                      dateStyle: 'short',
                      timeStyle: 'short'
                    })}
                  </span>
                </div>
              </div>

              <div className="history-item-actions">
                <button
                  className="btn-small btn-small-primary"
                  onClick={() => onSelectHistoryItem(item)}
                  title="ค้นหาคำนี้อีกครั้ง"
                >
                  <Search size={14} />
                  <span>ค้นหาซ้ำ</span>
                  <ArrowUpRight size={14} />
                </button>
                <button
                  className="btn-small"
                  style={{ color: '#ef4444' }}
                  onClick={() => onDeleteHistoryItem(index)}
                  title="ลบรายการนี้"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
