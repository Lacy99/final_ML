import React from 'react';
import { ArrowRight, Sparkles, Brain, BookOpen, MessageSquare, ShieldCheck, Zap } from 'lucide-react';

export default function HomeTab({ onStartSearch, onSelectExample }) {
  const sampleWords = ['สวย', 'ฉลาด', 'ดีใจ', 'อาหาร', 'รถยนต์', 'ทำงาน', 'น่ารัก'];

  return (
    <div className="home-container">
      {/* Hero Banner */}
      <section className="hero-section">
        <div className="hero-badge">
          <Sparkles size={16} />
          <span>ขับเคลื่อนด้วย AI for Thai Word Similarity API จริง</span>
        </div>

        <h1 className="hero-title">
          Thai Word Finder <br />
          <span className="hero-highlight">ระบบค้นหาคำที่มีความหมายใกล้เคียงด้วย AI</span>
        </h1>

        <p className="hero-desc">
          ประมวลผลข้อความภาษาไทยด้วยโมเดล Word2Vec จากคลังข้อมูลขนาดใหญ่
          ค้นหาคำที่มีบริบทสัมพันธ์กันและคำที่มีความหมายใกล้เคียง พร้อมแสดงคะแนนความคล้ายแบบแม่นยำ
        </p>

        <div className="hero-actions">
          <button className="btn-primary" onClick={onStartSearch}>
            <span>เริ่มค้นหาคำทันที</span>
            <ArrowRight size={18} />
          </button>
        </div>

        {/* Quick Example Chips */}
        <div className="examples-container" style={{ justifyContent: 'center', marginTop: '2rem' }}>
          <span className="examples-label">ลองเลือกคำตัวอย่าง:</span>
          {sampleWords.map((word) => (
            <button
              key={word}
              className="example-chip"
              onClick={() => onSelectExample(word)}
            >
              {word}
            </button>
          ))}
        </div>
      </section>

      {/* Feature Highlights */}
      <section className="features-grid">
        <div className="feature-card">
          <div className="feature-icon-wrapper">
            <Brain size={26} />
          </div>
          <h3 className="feature-title">AI for Thai API จริง</h3>
          <p className="feature-desc">
            เชื่อมต่อกับ Word Similarity API จากสำนักงานพัฒนาวิทยาศาสตร์และเทคโนโลยีแห่งชาติ (สวทช.)
            วิเคราะห์ความสัมพันธ์ของคำผ่านโมเดลประมวลผลภาษาธรรมชาติ (NLP)
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon-wrapper">
            <BookOpen size={26} />
          </div>
          <h3 className="feature-title">Thai Wikipedia Model</h3>
          <p className="feature-desc">
            โมเดล <code>thwiki</code> เทรนจากสารานุกรมวิกิพีเดียภาษาไทย
            เหมาะสำหรับการค้นหาคำศัพท์ทางการ วิชาการ และภาษาเขียนมาตรฐาน
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon-wrapper">
            <MessageSquare size={26} />
          </div>
          <h3 className="feature-title">Thai Twitter Model</h3>
          <p className="feature-desc">
            โมเดล <code>twitter</code> เทรนจากทวีตบนโซเชียลมีเดีย
            สะท้อนภาษาพูด คำสแลง และบริบทการสนทนาในชีวิตประจำวันของผู้ใช้งาน
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon-wrapper">
            <Zap size={26} />
          </div>
          <h3 className="feature-title">Cosine Similarity Score</h3>
          <p className="feature-desc">
            แสดงคะแนนความคล้ายทางเวกเตอร์ (Cosine Similarity) พร้อมคำนวณร้อยละ
            และแสดงแถบความคืบหน้า (Progress Bar) ลำดับคำอย่างชัดเจน
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon-wrapper">
            <ShieldCheck size={26} />
          </div>
          <h3 className="feature-title">ความปลอดภัยระดับสากล</h3>
          <p className="feature-desc">
            ไม่เปิดเผย API Key สู่เบราว์เซอร์ โดยทำงานผ่าน PHP Backend Proxy
            และเก็บกุญแจสำคัญไว้ใน Environment Variables เท่านั้น
          </p>
        </div>
      </section>
    </div>
  );
}
