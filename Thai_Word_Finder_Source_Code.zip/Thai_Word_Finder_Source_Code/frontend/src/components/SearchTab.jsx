import React from 'react';
import { Search, Sparkles, BookOpen, MessageSquare, AlertCircle, Inbox } from 'lucide-react';
import ResultCard from './ResultCard';
import ApiKeyAlert from './ApiKeyAlert';

export default function SearchTab({
  searchWord,
  setSearchWord,
  numWord,
  setNumWord,
  model,
  setModel,
  onSearch,
  loading,
  results,
  error,
  lastQuery
}) {
  const exampleWords = ['สวย', 'ฉลาด', 'ดีใจ', 'อาหาร', 'รถยนต์', 'ทำงาน', 'เหนื่อย', 'สนุก'];
  const numWordOptions = [5, 10, 15, 20];

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch();
  };

  return (
    <div className="search-page-container">
      {/* Search Input Box */}
      <div className="search-card">
        <div className="search-card-header">
          <h2 className="search-card-title">
            <Sparkles size={22} color="#2563eb" />
            <span>ค้นหาคำภาษาไทยที่มีความหมายใกล้เคียง</span>
          </h2>
          <p className="search-card-desc">
            ป้อนคำภาษาไทยที่ต้องการ แล้วเลือกจำนวนคำและโมเดลภาษาเพื่อประมวลผลผ่าน AI for Thai API
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="search-input-wrapper">
            <Search className="search-input-icon" size={24} />
            <input
              type="text"
              className="search-input"
              placeholder="ป้อนคำภาษาไทย เช่น สวย, ฉลาด, อาหาร..."
              value={searchWord}
              onChange={(e) => setSearchWord(e.target.value)}
              disabled={loading}
              autoFocus
            />
          </div>

          <div className="search-controls">
            {/* NumWord Options */}
            <div>
              <div className="control-group-title">จำนวนคำที่ต้องการค้นหา (numword):</div>
              <div className="pill-selector">
                {numWordOptions.map((n) => (
                  <button
                    key={n}
                    type="button"
                    className={`pill-btn ${numWord === n ? 'active' : ''}`}
                    onClick={() => setNumWord(n)}
                    disabled={loading}
                  >
                    {n} คำ
                  </button>
                ))}
              </div>
            </div>

            {/* Model Options */}
            <div>
              <div className="control-group-title">เลือกโมเดลภาษา (model):</div>
              <div className="pill-selector">
                <button
                  type="button"
                  className={`pill-btn ${model === 'thwiki' ? 'active' : ''}`}
                  onClick={() => setModel('thwiki')}
                  disabled={loading}
                >
                  <BookOpen size={14} style={{ display: 'inline', marginRight: '4px' }} />
                  Thai Wikipedia (thwiki)
                </button>
                <button
                  type="button"
                  className={`pill-btn ${model === 'twitter' ? 'active' : ''}`}
                  onClick={() => setModel('twitter')}
                  disabled={loading}
                >
                  <MessageSquare size={14} style={{ display: 'inline', marginRight: '4px' }} />
                  Thai Twitter (twitter)
                </button>
              </div>
            </div>
          </div>

          {/* Quick Examples */}
          <div className="examples-container">
            <span className="examples-label">คำค้นหายอดนิยม:</span>
            {exampleWords.map((word) => (
              <button
                key={word}
                type="button"
                className="example-chip"
                onClick={() => {
                  setSearchWord(word);
                  onSearch(word);
                }}
                disabled={loading}
              >
                {word}
              </button>
            ))}
          </div>

          {/* Search Button */}
          <div className="search-actions-bar">
            <button
              type="submit"
              className="btn-primary"
              disabled={loading || !searchWord.trim()}
              style={{ minWidth: '160px' }}
            >
              {loading ? (
                <>
                  <span className="spinner" style={{ width: '18px', height: '18px', borderWidth: '2px', margin: 0 }} />
                  <span>กำลังประมวลผล...</span>
                </>
              ) : (
                <>
                  <Search size={18} />
                  <span>ค้นหาคำใกล้เคียง</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Error / API Key Guide Alert */}
      {error && (
        <div>
          {error.error === 'MISSING_API_KEY' ? (
            <ApiKeyAlert errorData={error} />
          ) : (
            <div className="alert-card alert-danger">
              <AlertCircle size={22} style={{ flexShrink: 0 }} />
              <div>
                <div className="alert-title">เกิดข้อผิดพลาดในการประมวลผล</div>
                <div className="alert-message">{error.message || 'ไม่สามารถติดต่อ Backend หรือ API ได้'}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Loading Skeleton/State */}
      {loading && (
        <div className="loading-box">
          <div className="spinner" />
          <div className="loading-text">กำลังวิเคราะห์ความคล้ายของคำด้วย AI for Thai...</div>
          <div className="loading-subtext">
            กำลังส่งคำค้นหาไปยัง Backend PHP และเรียกใช้ Word Similarity API ({model === 'thwiki' ? 'Thai Wikipedia' : 'Thai Twitter'})
          </div>
        </div>
      )}

      {/* Results Display */}
      {!loading && results && results.words && (
        <div>
          <div className="results-header-card">
            <div className="results-meta">
              <span className="query-word-badge">คำค้นหา: "{lastQuery?.word}"</span>
              <span className="results-count-text">
                พบผลลัพธ์ทั้งหมด {results.words.length} คำ (โมเดล: {lastQuery?.model_label || lastQuery?.model})
              </span>
            </div>
            <div className="note-disclaimer">
              * คะแนน (Score) คือ Cosine Similarity ของโมเดลเวกเตอร์ ไม่ใช่ความน่าจะเป็นที่คำมีความหมายเหมือนกันโดยตรง
            </div>
          </div>

          {results.words.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">
                <Inbox size={32} />
              </div>
              <h3 className="empty-title">ไม่พบคำที่ใกล้เคียงในคลังคำศัพท์</h3>
              <p className="empty-desc">
                คำว่า "{lastQuery?.word}" อาจไม่มีอยู่ในฐานข้อมูลของโมเดล {lastQuery?.model}
                ลองเปลี่ยนคำค้นหา หรือสลับโมเดลเป็น {lastQuery?.model === 'thwiki' ? 'Twitter' : 'Wikipedia'}
              </p>
            </div>
          ) : (
            <div className="words-grid">
              {results.words.map((item) => (
                <ResultCard key={`${item.rank}-${item.word}`} item={item} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
