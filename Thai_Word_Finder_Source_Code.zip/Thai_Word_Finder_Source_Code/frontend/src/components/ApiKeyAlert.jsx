import React, { useState } from 'react';
import { AlertTriangle, ExternalLink, Copy, Check } from 'lucide-react';

export default function ApiKeyAlert({ errorData }) {
  const [copied, setCopied] = useState(false);
  const sampleEnvText = 'AIFORTHAI_API_KEY=your_actual_api_key_here';

  const copyEnvSnippet = () => {
    navigator.clipboard.writeText(sampleEnvText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="apikey-guide-box">
      <div className="apikey-guide-header">
        <AlertTriangle size={24} color="#f59e0b" />
        <span>คำแนะนำ: ยังไม่ได้กำหนดค่า AIFORTHAI_API_KEY</span>
      </div>

      <p style={{ marginBottom: '1rem', color: '#475569', fontSize: '0.95rem' }}>
        {errorData?.message ||
          'ระบบตรวจพบว่ายังไม่ได้ตั้งค่า API Key ในไฟล์ backend/.env เพื่อความปลอดภัยและความโปร่งใส ระบบจะไม่สร้างผลลัพธ์จำลอง'}
      </p>

      <ol className="apikey-steps">
        <li>
          สมัครสมาชิกฟรีและสร้าง API Key ที่เว็บไซต์ทางการ{' '}
          <a
            href="https://aiforthai.in.th/"
            target="_blank"
            rel="noopener noreferrer"
            style={{ fontWeight: 600, textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '2px' }}
          >
            aiforthai.in.th <ExternalLink size={14} />
          </a>
        </li>
        <li>
          เปิดโฟลเดอร์ <code>backend/</code> แล้วค้นหาไฟล์ <code>.env</code> (หรือคัดลอกจาก <code>.env.example</code>)
        </li>
        <li>
          กำหนดค่า API Key ที่ได้รับลงในไฟล์ <code>backend/.env</code> ดังตัวอย่าง:
        </li>
      </ol>

      <div className="code-snippet">
        <code>{sampleEnvText}</code>
        <button
          className="copy-btn"
          style={{ background: 'rgba(255,255,255,0.15)', color: '#ffffff' }}
          onClick={copyEnvSnippet}
        >
          {copied ? <Check size={14} /> : <Copy size={14} />}
          <span>{copied ? 'คัดลอกแล้ว' : 'คัดลอก'}</span>
        </button>
      </div>

      <p style={{ marginTop: '1rem', fontSize: '0.85rem', color: '#64748b' }}>
        * ไฟล์ <code>backend/.env</code> ได้รับการป้องกันผ่าน <code>.gitignore</code> แล้ว เพื่อไม่ให้ API Key หลุดขึ้นสู่ GitHub สาธารณะ
      </p>
    </div>
  );
}
