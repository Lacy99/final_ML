import React from 'react';
import { Info, Cpu, Network, ShieldCheck, Database, Layers, ExternalLink } from 'lucide-react';

export default function AboutTab() {
  return (
    <div className="about-section">
      {/* Overview Card */}
      <div className="about-card">
        <h2 className="about-title">
          <Info size={24} color="#2563eb" />
          <span>วัตถุประสงค์ของโครงการ Thai Word Finder</span>
        </h2>
        <p className="about-text">
          ระบบ <strong>Thai Word Finder</strong> ถูกพัฒนาขึ้นเพื่อเป็นโครงงานศึกษาและประยุกต์ใช้ปัญญาประดิษฐ์ (AI)
          และการประมวลผลภาษาธรรมชาติ (Natural Language Processing: NLP) สำหรับภาษาไทย
          โดยมุ่งเน้นการเชื่อมต่อกับบริการ AI API ชั้นนำของประเทศไทยอย่าง <strong>AI for Thai</strong> เพื่อให้ผู้ใช้งานสามารถค้นหาคำศัพท์ที่มีความหมายใกล้เคียง
          คำที่มีบริบทสัมพันธ์กัน และช่วยในการสร้างสรรค์เนื้อหา การเขียนบทความ หรือการวิจัยด้านภาษาศาสตร์
        </p>
      </div>

      {/* Architecture & Data Flow */}
      <div className="about-card">
        <h2 className="about-title">
          <Network size={24} color="#2563eb" />
          <span>สถาปัตยกรรมและการไหลของข้อมูล (System Architecture & Data Flow)</span>
        </h2>
        <p className="about-text">
          ระบบถูกออกแบบตามหลักการ Secure Client-Server Architecture เพื่อป้องกันการเปิดเผย API Key สู่สาธารณะ:
        </p>

        <div className="architecture-flow">
          <div className="flow-step-card">
            <div className="flow-step-num">1</div>
            <div className="flow-step-title">Frontend (React)</div>
            <div className="flow-step-desc">
              ผู้ใช้ป้อนคำค้นหา เลือกโมเดล และจำนวนคำ จากนั้นส่ง HTTP POST Request ไปยัง Backend
            </div>
          </div>

          <div className="flow-step-card">
            <div className="flow-step-num">2</div>
            <div className="flow-step-title">Backend (PHP)</div>
            <div className="flow-step-desc">
              ตรวจสอบข้อมูล (Validation) และอ่าน <code>AIFORTHAI_API_KEY</code> จากไฟล์ <code>.env</code>
            </div>
          </div>

          <div className="flow-step-card">
            <div className="flow-step-num">3</div>
            <div className="flow-step-title">AI for Thai API</div>
            <div className="flow-step-desc">
              Backend เรียก API ผ่าน PHP cURL ส่ง Header <code>Apikey</code> ไปยังเซิร์ฟเวอร์ สวทช.
            </div>
          </div>

          <div className="flow-step-card">
            <div className="flow-step-num">4</div>
            <div className="flow-step-title">Result Visualization</div>
            <div className="flow-step-desc">
              Frontend รับผลลัพธ์ คำนวณเปอร์เซ็นต์ จัดอันดับ และเรนเดอร์ Progress Bar สวยงาม
            </div>
          </div>
        </div>
      </div>

      {/* AI for Thai Word Similarity Details */}
      <div className="about-card">
        <h2 className="about-title">
          <Cpu size={24} color="#2563eb" />
          <span>เกี่ยวกับบริการ AI for Thai Word Similarity API</span>
        </h2>
        <p className="about-text">
          บริการ <strong>Word Similarity API</strong> ของแพลตฟอร์ม AI for Thai (โดย สวทช.) พัฒนาบนพื้นฐานของโมเดล{' '}
          <strong>Word2Vec (Skip-gram / CBOW)</strong> ซึ่งแปลงคำภาษาไทยให้เป็นเวกเตอร์หลายมิติ (Word Embeddings)
        </p>

        <div className="tech-stack-grid">
          <div className="tech-badge-card">
            <div className="tech-badge-title">Thai Wikipedia (thwiki)</div>
            <div className="tech-badge-desc">
              สร้างจากคลังข้อมูลสารานุกรมวิกิพีเดียภาษาไทย คำที่ได้จะเป็นศัพท์ทางการ ภาษาเขียน และบริบทความรู้เชิงวิชาการ
            </div>
          </div>

          <div className="tech-badge-card">
            <div className="tech-badge-title">Thai Twitter (twitter)</div>
            <div className="tech-badge-desc">
              สร้างจากข้อความทวีตบนโซเชียลมีเดีย คำที่ได้จะสะท้อนถึงคำสแลง ภาษาพูด อารมณ์ความรู้สึก และบทสนทนาในชีวิตประจำวัน
            </div>
          </div>

          <div className="tech-badge-card">
            <div className="tech-badge-title">Cosine Similarity (คะแนนความคล้าย)</div>
            <div className="tech-badge-desc">
              คะแนนระหว่าง -1.0 ถึง 1.0 (ค่าส่วนใหญ่ในผลลัพธ์จะอยู่ระหว่าง 0.4 - 0.9) คำนวณจากมุมระหว่างเวกเตอร์ของสองคำ
              ยิ่งใกล้ 1.0 แสดงว่ามีบริบทการใช้งานร่วมกันบ่อยครั้งมาก
            </div>
          </div>
        </div>

        <div style={{ marginTop: '1.25rem' }}>
          <a
            href="https://aiforthai.in.th/service_detail.php?id=8"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.9rem' }}
          >
            <span>ดูเอกสาร API ทางการที่ aiforthai.in.th</span>
            <ExternalLink size={16} />
          </a>
        </div>
      </div>

      {/* Technology Stack Details */}
      <div className="about-card">
        <h2 className="about-title">
          <Layers size={24} color="#2563eb" />
          <span>เทคโนโลยีที่ใช้ในการพัฒนา</span>
        </h2>

        <div className="tech-stack-grid">
          <div className="tech-badge-card">
            <div className="tech-badge-title">Frontend: React 18 + Vite</div>
            <div className="tech-badge-desc">
              คอมโพเนนต์แบบโมดูลาร์ ประมวลผลรวดเร็วด้วย Vite Build Tool และการจัดการ State ภายในแอปพลิเคชัน
            </div>
          </div>

          <div className="tech-badge-card">
            <div className="tech-badge-title">Styling: Handcrafted Pure CSS</div>
            <div className="tech-badge-desc">
              เขียน CSS เอง 100% ไม่พึ่งพา Tailwind หรือ Bootstrap ตรงตามข้อกำหนด Modern AI Dashboard
            </div>
          </div>

          <div className="tech-badge-card">
            <div className="tech-badge-title">Backend: PHP 8.2+ บน XAMPP</div>
            <div className="tech-badge-desc">
              RESTful Proxy API พร้อมระบบตรวจสอบความถูกต้อง (Validation) และ cURL Network Client
            </div>
          </div>

          <div className="tech-badge-card">
            <div className="tech-badge-title">Security & Environment</div>
            <div className="tech-badge-desc">
              เก็บความลับใน <code>.env</code> แยกต่างหาก มีไฟล์ตัวอย่าง <code>.env.example</code> และตัดสิทธิ์ผ่าน <code>.gitignore</code>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
