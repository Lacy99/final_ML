import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

export default function ResultCard({ item }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(item.word);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const rankClass = item.rank === 1 ? 'rank-1' : item.rank === 2 ? 'rank-2' : item.rank === 3 ? 'rank-3' : '';

  return (
    <div className={`word-card ${rankClass}`}>
      <div className="card-top">
        <span className="rank-badge" title={`อันดับที่ ${item.rank}`}>
          #{item.rank}
        </span>
        <button
          className={`copy-btn ${copied ? 'copied' : ''}`}
          onClick={handleCopy}
          title="คัดลอกคำนี้"
        >
          {copied ? (
            <>
              <Check size={14} />
              <span>คัดลอกแล้ว</span>
            </>
          ) : (
            <>
              <Copy size={14} />
              <span>คัดลอก</span>
            </>
          )}
        </button>
      </div>

      <div className="word-title">{item.word}</div>

      <div className="card-bottom">
        <div className="score-stats">
          <span className="score-percentage">{item.percentage}%</span>
          <span className="score-raw">Score: {item.score.toFixed(4)}</span>
        </div>

        <div className="progress-container">
          <div
            className="progress-bar-fill"
            style={{ width: `${Math.min(Math.max(item.percentage, 5), 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
}
