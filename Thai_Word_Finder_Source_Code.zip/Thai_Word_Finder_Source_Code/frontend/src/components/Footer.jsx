import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-top">
          <div>
            <div className="footer-brand">Thai Word Finder</div>
            <p className="footer-credits">
              ระบบค้นหาคำที่มีความหมายใกล้เคียงด้วย AI for Thai Word Similarity API
            </p>
          </div>
          <div className="footer-credits">
            วิชา Machine Learning / Web Application Development
          </div>
        </div>

        <div className="footer-bottom">
          <span>&copy; {new Date().getFullYear()} Thai Word Finder Project. All rights reserved.</span>
          <span>พัฒนาด้วย React + Vite, PHP 8+ บน XAMPP & Antigravity CLI</span>
        </div>
      </div>
    </footer>
  );
}
