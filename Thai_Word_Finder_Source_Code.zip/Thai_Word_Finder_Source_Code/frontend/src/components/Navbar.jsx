import React from 'react';
import { Sparkles, Search, History, Info, Home } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, backendStatus }) {
  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div className="brand-link" onClick={() => setActiveTab('home')}>
          <div className="brand-icon">
            <Sparkles size={22} />
          </div>
          <div className="brand-text-container">
            <span className="brand-title">Thai Word Finder</span>
            <span className="brand-subtitle">AI for Thai Word Similarity</span>
          </div>
        </div>

        <nav>
          <ul className="nav-menu">
            <li>
              <button
                className={`nav-item-btn ${activeTab === 'home' ? 'active' : ''}`}
                onClick={() => setActiveTab('home')}
              >
                <Home size={18} />
                <span>หน้าแรก</span>
              </button>
            </li>
            <li>
              <button
                className={`nav-item-btn ${activeTab === 'search' ? 'active' : ''}`}
                onClick={() => setActiveTab('search')}
              >
                <Search size={18} />
                <span>ค้นหาคำ</span>
              </button>
            </li>
            <li>
              <button
                className={`nav-item-btn ${activeTab === 'history' ? 'active' : ''}`}
                onClick={() => setActiveTab('history')}
              >
                <History size={18} />
                <span>ประวัติ</span>
              </button>
            </li>
            <li>
              <button
                className={`nav-item-btn ${activeTab === 'about' ? 'active' : ''}`}
                onClick={() => setActiveTab('about')}
              >
                <Info size={18} />
                <span>เกี่ยวกับระบบ</span>
              </button>
            </li>
          </ul>
        </nav>

        <div className="backend-status-pill" title={`สถานะ Backend: ${backendStatus}`}>
          <span className={`status-dot ${backendStatus === 'online' ? 'online' : 'offline'}`} />
          <span>Backend {backendStatus === 'online' ? 'พร้อมใช้งาน' : 'กำลังเชื่อมต่อ'}</span>
        </div>
      </div>
    </header>
  );
}
