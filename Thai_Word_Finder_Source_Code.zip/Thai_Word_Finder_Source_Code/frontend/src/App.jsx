import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomeTab from './components/HomeTab';
import SearchTab from './components/SearchTab';
import HistoryTab from './components/HistoryTab';
import AboutTab from './components/AboutTab';
import './App.css';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [searchWord, setSearchWord] = useState('');
  const [numWord, setNumWord] = useState(10);
  const [model, setModel] = useState('thwiki');

  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [lastQuery, setLastQuery] = useState(null);

  const [history, setHistory] = useState([]);
  const [backendStatus, setBackendStatus] = useState('checking');

  // ตรวจสอบ Endpoint URL ที่เหมาะสม (Vite proxy, PHP Server หรือ XAMPP Apache)
  const getApiUrl = (endpoint) => {
    // หากมี Environment variable VITE_API_BASE_URL ให้ใช้ค่านั้น
    if (import.meta.env.VITE_API_BASE_URL) {
      return `${import.meta.env.VITE_API_BASE_URL}/${endpoint}`;
    }
    // ปกติเรียกผ่าน Vite proxy: /backend/api/<endpoint>
    return `/backend/api/${endpoint}`;
  };

  // โหลดประวัติการค้นหาจาก localStorage
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem('thai_wordsim_history');
      if (savedHistory) {
        setHistory(JSON.parse(savedHistory));
      }
    } catch (err) {
      console.error('ไม่สามารถโหลดประวัติจาก localStorage ได้:', err);
    }
  }, []);

  // บันทึกประวัติลงใน localStorage (ไม่เก็บ API Key ใดๆ)
  const saveToHistory = (queryWord, queryModel, queryNumWord, count) => {
    try {
      const newItem = {
        word: queryWord,
        model: queryModel,
        numword: queryNumWord,
        resultCount: count,
        timestamp: new Date().toISOString()
      };

      // กรองคำซ้ำออก แล้วนำคำใหม่ไว้ด้านบนสุด (จำกัด 30 รายการ)
      const updated = [newItem, ...history.filter((h) => h.word !== queryWord || h.model !== queryModel)].slice(0, 30);
      setHistory(updated);
      localStorage.setItem('thai_wordsim_history', JSON.stringify(updated));
    } catch (err) {
      console.error('ไม่สามารถบันทึกประวัติลง localStorage ได้:', err);
    }
  };

  // ตรวจสอบสถานะ Backend ผ่าน health.php
  useEffect(() => {
    const checkBackend = async () => {
      try {
        const res = await fetch(getApiUrl('health.php'));
        if (res.ok) {
          const data = await res.json();
          if (data.status === 'ok') {
            setBackendStatus('online');
            return;
          }
        }
        setBackendStatus('offline');
      } catch (e) {
        // Fallback: ลองเชื่อมต่อกับ localhost:8000 โดยตรงหาก proxy มีปัญหา
        try {
          const directRes = await fetch('http://localhost:8000/backend/api/health.php');
          if (directRes.ok) {
            setBackendStatus('online');
            return;
          }
        } catch (_) {}
        setBackendStatus('offline');
      }
    };

    checkBackend();
  }, []);

  // ฟังก์ชันค้นหาคำที่มีความหมายใกล้เคียง
  const handleSearch = async (overrideWord, overrideNum, overrideModel) => {
    const targetWord = (overrideWord !== undefined ? overrideWord : searchWord).trim();
    const targetNum = overrideNum !== undefined ? overrideNum : numWord;
    const targetModel = overrideModel !== undefined ? overrideModel : model;

    if (!targetWord) {
      setError({
        error: 'EMPTY_WORD',
        message: 'กรุณากรอกคำภาษาไทยที่ต้องการค้นหา'
      });
      return;
    }

    setLoading(true);
    setError(null);

    // กำหนด URL สำหรับเรียก Backend
    let apiUrl = getApiUrl('word-similarity.php');

    try {
      let res;
      try {
        res = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            word: targetWord,
            numword: targetNum,
            model: targetModel
          })
        });
      } catch (networkErr) {
        // กรณี proxy ไม่ทำงาน ลองเรียกตรงไปที่ http://localhost:8000
        res = await fetch('http://localhost:8000/backend/api/word-similarity.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            word: targetWord,
            numword: targetNum,
            model: targetModel
          })
        });
      }

      const data = await res.json();

      if (!res.ok || !data.success) {
        setError(data);
        setResults(null);
      } else {
        setResults(data);
        setLastQuery(data.query);
        saveToHistory(targetWord, targetModel, targetNum, data.count);
      }
    } catch (err) {
      setError({
        error: 'CONNECTION_FAILED',
        message: 'ไม่สามารถติดต่อเซิร์ฟเวอร์ Backend PHP ได้ กรุณาตรวจสอบว่า PHP Server ทำงานอยู่ที่ localhost:8000 หรือ XAMPP Apache ทำงานอยู่'
      });
      setResults(null);
    } finally {
      setLoading(false);
    }
  };

  // จัดการเมื่อเลือกคำจากหน้าแรก
  const handleSelectExample = (word) => {
    setSearchWord(word);
    setActiveTab('search');
    handleSearch(word, numWord, model);
  };

  // จัดการเมื่อคลิกประวัติการค้นหา
  const handleSelectHistoryItem = (item) => {
    setSearchWord(item.word);
    setNumWord(item.numword);
    setModel(item.model);
    setActiveTab('search');
    handleSearch(item.word, item.numword, item.model);
  };

  // ล้างประวัติทั้งหมด
  const handleClearHistory = () => {
    if (window.confirm('คุณต้องการล้างประวัติการค้นหาทั้งหมดใช่หรือไม่?')) {
      setHistory([]);
      localStorage.removeItem('thai_wordsim_history');
    }
  };

  // ลบประวัติรายการเดียว
  const handleDeleteHistoryItem = (index) => {
    const updated = history.filter((_, i) => i !== index);
    setHistory(updated);
    localStorage.setItem('thai_wordsim_history', JSON.stringify(updated));
  };

  return (
    <div className="app-container">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        backendStatus={backendStatus}
      />

      <main className="main-content">
        {activeTab === 'home' && (
          <HomeTab
            onStartSearch={() => setActiveTab('search')}
            onSelectExample={handleSelectExample}
          />
        )}

        {activeTab === 'search' && (
          <SearchTab
            searchWord={searchWord}
            setSearchWord={setSearchWord}
            numWord={numWord}
            setNumWord={setNumWord}
            model={model}
            setModel={setModel}
            onSearch={handleSearch}
            loading={loading}
            results={results}
            error={error}
            lastQuery={lastQuery}
          />
        )}

        {activeTab === 'history' && (
          <HistoryTab
            history={history}
            onSelectHistoryItem={handleSelectHistoryItem}
            onClearHistory={handleClearHistory}
            onDeleteHistoryItem={handleDeleteHistoryItem}
          />
        )}

        {activeTab === 'about' && <AboutTab />}
      </main>

      <Footer />
    </div>
  );
}
